﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class Coordinate
    {
        public double lon { get; set; }
        public double lat { get; set; }
    }
}